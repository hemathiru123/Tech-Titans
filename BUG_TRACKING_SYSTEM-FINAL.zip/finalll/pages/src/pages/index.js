// Filename - pages/index.js

import React from "react";
import { Link } from "react-router-dom";
import SignUp from "./signup";
const Home = () => {
	return (
		<div>
			<h1>Welcome to Bug Tracker</h1>
			<h2>Sign In to Start</h2>
			<div id="validation">
				<form>
					<label for="email" >Email:</label>
					<input type="email" id="email" name="email" required ></input>
					<label for="password" >Password:</label>
					<input type="password" id="password" name="password" required minlength="6" ></input>
					<Link to="Blogs">  <button type="submit">Login</button></Link>
				</form>
				
				
			</div>
			<p>Don't have an account? <Link to={SignUp}> Signup </Link> </p>
			
		</div>
	);
};

export default Home;
