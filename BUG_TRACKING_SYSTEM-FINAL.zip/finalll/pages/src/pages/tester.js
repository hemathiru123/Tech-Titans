import React from "react";
import DataTable from 'react-data-table-component';
function Tester(){
        const testerColumns = [
            {
              name:'Tester ID',
              selector: row => row.tester_id,
              sortable: true
            },
            {
              name:'Tester Name',
              selector: row => row.tester_name,
              sortable: true
            },
            {
              name:'Tester Email',
              selector: row => row.tester_email,
              sortable: true
            },
            {
              name:'Tester Availability',
              selector:row => row.tester_availability,
            }
          ];
          const testerData = [
            {
              tester_id: 1,
              tester_name: 'Rahul',
              tester_email: 'rahul@gmail.com',
              tester_availability: 'Available',
            },
            {
              tester_id: 2,
              tester_name: 'Nisha',
              tester_email: 'nisha@gmail.com',
              tester_availability: 'Not Available',
            },
            {
              tester_id: 3,
              tester_name: 'Aryan',
              tester_email: 'aryan@gmail.com',
              tester_availability: 'Available',
            },
            {
              tester_id: 4,
              tester_name: 'Sneha',
              tester_email: 'sneha@gmail.com',
              tester_availability: 'Not Available',
            },
            {
              tester_id: 5,
              tester_name: 'Vivek',
              tester_email: 'vivek@gmail.com',
              tester_availability: 'Available',
            },
            {
              tester_id: 6,
              tester_name: 'Neha',
              tester_email: 'neha@gmail.com',
              tester_availability: 'Not Available',
            },
          ];
        return(
            <div className="container mt-5">
                <h2>Tester Table</h2>
                <DataTable columns={testerColumns} data={testerData} />
            </div>  
        );
}
export default Tester;