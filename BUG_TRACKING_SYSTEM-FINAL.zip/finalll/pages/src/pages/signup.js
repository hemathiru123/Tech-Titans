// Filename - pages/signup.js

import React from "react";
import "./signup.css";
import { Link } from "react-router-dom";
const SignUp = () => {

	return (
		<>
			<h1>Welcome to Bug Tracker</h1>
			<h2>Sign In to Start</h2>
			<div id="validation">
				
				<form>
					<label for="email" >Email:</label>
					<input type="email" id="email" name="email" required ></input>
					<label for="password" >Password:</label>
					<input type="password" id="password" name="password" required minlength="6" ></input>
					<button  type="submit">Signup</button>
				</form>
			</div>
			<p>Already have an account? <Link to="login.js">Login</Link></p>
		</>
	);
}
export default SignUp;
