// Filename - pages/blogs.js

import React from "react";

const Blogs = () => {
	return(
		<>
			<h2>Request Here To Test Your Website</h2>
			<div id="request">
				<form  method="post" enctype="multipart/form-data">
					<label for="url">URL:</label>
					<input type="url" id="url" name="url" required />
					<label for="credentials">Credentials:</label>
					<input type="text" id="credentials" name="credentials" required />
					<label for="source">Source (optional):</label>
					<input type="file" id="source" name="source" />
					<input type="submit" value="Submit" />
				</form>
			</div>
		</>
	)
};

export default Blogs;
