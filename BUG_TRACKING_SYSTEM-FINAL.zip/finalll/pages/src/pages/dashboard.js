import React from "react";
import 
{BsExclamationCircleFill  ,BsExclamationTriangleFill ,BsPeopleFill,BsFillBellFill } from "react-icons/bs";
// import { BarChart, Bar, Rectangle, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

import "./dashboard.css";
function Dashboard(){
        //  const data = [
        //      {
        //      name: 'Week 1',
        //      Indentified: 16,
        //      Solved: 12,
        //      amt: 20,
        //      },
        //      {
        //      name: 'Week 2',
        //      Indentified: 13,
        //      Solved: 9,
        //      amt: 22,
        //      },
        //      {
        //      name: 'Week 3',
        //      Indentified: 25,
        //      Solved: 19,
        //      amt: 25,
        //      },
        //      {
        //      name: 'Week 4',
        //      Indentified: 35,
        //      Solved: 28,
        //      amt: 40,
        //      },
        //      {
        //      name: 'Week 5',
        //      Indentified: 9,
        //      Solved: 8,
        //      amt: 10,
        //      },
        //      {
        //      name: 'Week 6',
        //      Indentified: 5,
        //      Solved: 4,
        //      amt: 5,
        //      },
        //  ];
        
         return(
            <main className="main-container">
                <div className="main-title">
                    <h2>CUSTOMER DASHBOARD</h2>
                </div>
                
                <div className="main-cards">
                    <div className="card">
                        <div className="card-inner">
                            <h3>Bug Status</h3>
                            <BsExclamationTriangleFill    className="card_icon"/>
                        </div>
                        <h3>Under Triage</h3>
                    </div>
                    <div className="card">
                        <div className="card-inner">
                            <h3>Identified Bugs</h3>
                            <BsExclamationCircleFill className="card_icon"/>
                        </div>
                        <h3>85.37%</h3>
                    </div>
                    <div className="card">
                        <div className="card-inner">
                            <h3>Solved Bugs </h3>
                            <BsPeopleFill className="card_icon"/>
                        </div>
                        <h3>63.42%</h3>
                    </div>
                    <div className="card">
                        <div className="card-inner">
                            <h3>Unsolved Bugs</h3>
                            <BsFillBellFill className="card_icon"/>
                        </div>
                        <h3>32.62%</h3>
                    </div>
                </div>
                {/* <div className="charts">
                 <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                    width={800}
                    height={500}
                    data={data}
                    margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                    }}
                    >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Identified" fill="#8884d8" activeBar={<Rectangle fill="pink" stroke="blue" />} />
                    <Bar dataKey="Solved" fill="#82ca9d" activeBar={<Rectangle fill="gold" stroke="purple" />} />
                    </BarChart>
                </ResponsiveContainer>
                </div> */}
            </main>
        
         );
    }


export default Dashboard;