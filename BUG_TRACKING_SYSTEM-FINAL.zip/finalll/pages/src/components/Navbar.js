// Filename - "./components/Navbar.js

import React from "react";
import { Nav, NavLink, NavMenu } from "./NavbarElements";

const Navbar = () => {
	return (
		<>
            
			<Nav>
				<NavMenu>
                    <h1>Bug Tracker </h1>
					{/* <NavLink to="/about" activeStyle>
						<h4>About</h4>
					</NavLink> */}
					<NavLink to="/sign-up" activeStyle>
                    <h4>Sign Up</h4>
					</NavLink>
					 <NavLink to="/blogs" activeStyle>
                    <h4>Request</h4>
					</NavLink> 
                    <NavLink to="/dashboard" activeStyle>
                    <h4>Dashboard</h4>
					</NavLink>
					<NavLink to="/projectmanager" activeStyle>
                    <h4>Project Manager</h4>
					</NavLink>
					<NavLink to="/tester" activeStyle>
                    <h4>Tester</h4>
					</NavLink>
				</NavMenu>
			</Nav>
		</>
	);
};

export default Navbar;
