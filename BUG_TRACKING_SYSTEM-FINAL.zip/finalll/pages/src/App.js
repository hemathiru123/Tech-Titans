// Filename - App.js

import React from "react";
import Navbar from "./components/Navbar";
import {
	BrowserRouter as Router,
	Routes,
	Route,
} from "react-router-dom";
// import Home from "./pages";
import About from "./pages/about";
import Blogs from "./pages/blogs";
import Project from "./pages/projectmanager";
import Tester from "./pages/tester";
import Signup from "./pages/signup";
import Login from "./pages/login";
import Home from "./pages";
import Dashboard from "./pages/dashboard";

function App() {
	return (
		<Router>
			<Navbar />
			<Routes>
				{/* <Route exact path="/" element={<Home />} /> */}
        		<Route exact path="/login" element={<Login />} />
				<Route path="/about" element={<About />} />
        		<Route path="/dashboard" element={ <Dashboard/> } />
				<Route path="/blogs" element={<Blogs />} />
				
				<Route path="/sign-up" element={<Signup />} />
				<Route path="/" element={<Home />} />
				<Route path="/tester" element={<Tester />} />
				<Route path="/projectmanager" element={<Project />} />
				
			</Routes>
		</Router>
	
		   
   
	);
}

export default App;
